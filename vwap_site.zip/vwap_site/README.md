# VWAP Chart Lab

Streamlit app to overlay VWAP and Anchored VWAP on any ticker (default: TSLA).

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```
